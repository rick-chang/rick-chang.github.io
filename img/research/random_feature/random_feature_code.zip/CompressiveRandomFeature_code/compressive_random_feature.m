% Compressive random feature
% by Jen-Hao Rick Chang 
% For details see the paper: 
%   Random features for sparse signal classification, 
%   Jen-Hao Rick Chang, Aswin C Sankaranarayanan, and BVK Vijaya Kumar, 
%   CVPR 2016

% create fake dataset for demonstration purpose
total_data = 1000;
d = 100;
X = randn(d, total_data);
X(abs(X) > 0.1) = 0;  % signal should be sparse canonically or after transformation  

% setting for Gaussian kernel 
sigma = 1;
gamma = 1/(2*sigma^2);

% construct typical Fourier random features
M = 100; % dimension of random features
b = 2*pi*rand(M,1);
W = (sqrt(2*gamma)) * randn(M,d);
phi_typical = @(x) 1/sqrt(M) * sqrt(2)*cos(bsxfun(@plus, W*x, b));
fourier_random_features = phi_typical(X);

% construct compressive random feature
m = 20; % dimension for dimension reduction
R = randn(m,d)/sqrt(m); % gaussian random matrix
R = gram_schmidt(R')' * sqrt(d/m); % orthogonalize R's row
dimension_reduction = @(x)(R*x);
% construct random feature
b = 2*pi*rand(M,1);
W = (sqrt(2*gamma)) * randn(M,m);
phi_compressive = @(x) 1/sqrt(M) * sqrt(2)*cos(bsxfun(@plus, W*(dimension_reduction(x)), b));
compressive_random_features = phi_compressive(X);

